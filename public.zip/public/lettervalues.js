function getLetterPoints(letter) {
    switch (letter) {
        case "A":
            return 1
        case "B":
            return 3
        case "C":
            return 4
        case "D":
            return 1
        case "E":
            return 1
        case "F":
            return 4
        case "G":
            return 2
        case "H":
            return 2
        case "I":
            return 1
        case "J":
            return 6
        case "K":
            return 4
        case "L":
            return 2
        case "M":
            return 3
        case "N":
            return 1
        case "O":
            return 2
        case "P":
            return 4
        case "Q":
            return 10
        case "R":
            return 1
        case "S":
            return 1
        case "T":
            return 1
        case "U":
            return 1
        case "V":
            return 6
        case "W":
            return 3
        case "X":
            return 8
        case "Y":
            return 10
        case "Z":
            return 3
        default:
            return 0
    }
}